#ifndef KEYBOARDUTILITIES_H
#define KEYBOARDUTILITIES_H

void cleanBuffer(void);
//funcion encargada de limpiar el buffer
#endif
