#ifndef COLORS_H
#define COLORS_H

#define GREEN   "\x1b[32m"
#define BLUE    "\x1b[34m"
#define COLOR_RESET   "\x1b[0m"
//Punteros a color para linux
#endif