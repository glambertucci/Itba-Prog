#ifndef MESSAGES_H
#define MESSAGES_H

void welcomeMessage(void);
void invalidMessage(void);
void indefiniteMessage(void);
void answerMessage(double num1, char op, double num2, double result);

void endMessage(void);
//Imprime por terminal los mensajes para el usuario
#endif
