#ifndef MODESELECTION_H
#define MODESELECTION_H
#define MAX_SIZE 1000
int modeAsk(void);
//define el modo a utilizar 
#endif
